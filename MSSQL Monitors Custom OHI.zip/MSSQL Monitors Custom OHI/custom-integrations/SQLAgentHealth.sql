SELECT a.name as JobName,a.description as JobDescription,    b.last_run_date,b.last_run_time,
            CONVERT(DATETIME, CONVERT(CHAR(8), b.last_run_date, 112) + ' '
            + STUFF(STUFF(RIGHT('000000' + CONVERT(VARCHAR(8), b.last_run_time), 6), 5, 0, ':'), 3, 0, ':'), 121) as LastRunDateTime,
            (b.last_run_duration/10000)*3600 + ((b.last_run_duration%10000)/100)*60 + (b.last_run_duration%100) as LastRunDuration,DATEADD(s,ISNULL(b.last_run_duration,0),CONVERT(DATETIME, CONVERT(CHAR(8), b.last_run_date, 112) + ' ' + STUFF(STUFF(RIGHT('000000' + CONVERT(VARCHAR(8), b.last_run_time), 6), 5, 0, ':'), 3, 0, ':'), 121)) as LastRunEndDateTime,b.last_outcome_message
FROM msdb.dbo.sysjobs a
join  msdb.dbo.sysjobservers b on a.job_id=b.job_id
WHERE last_run_outcome =0 and a.enabled=1         