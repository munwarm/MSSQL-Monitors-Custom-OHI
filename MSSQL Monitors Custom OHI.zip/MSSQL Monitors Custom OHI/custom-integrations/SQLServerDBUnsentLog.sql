IF EXISTS(
        SELECT database_id
        FROM sys.database_mirroring
        WHERE mirroring_guid IS NOT NULL
    )
BEGIN
        CREATE TABLE #tempTable(
            database_name   sysname,[role]  int  ,mirroring_state   int  ,
            witness_status  int,log_generation_rate int,unsent_log  int ,
            send_rate   int  ,unrestored_log    int ,recovery_rate  int,
            transaction_delay   int  ,transactions_per_sec int ,average_delay   int ,
            time_recorded   datetime,time_behind    datetime ,local_time    datetime)
        DECLARE @l_DatabaseName VARCHAR(75),@l_i INT
        SELECT database_id,DB_NAME(database_id) AS database_name
        INTO #mirrorDatabases
        from sys.database_mirroring WITH(NOLOCK)
        WHERE mirroring_guid IS NOT NULL
        SELECT @l_i = MIN(database_id)
        FROM #mirrorDatabases
        WHILE(@l_i IS NOT NULL)
        BEGIN
            SELECT @l_DatabaseName = database_name
            FROM #mirrorDatabases
            WHERE database_id = @l_i
            exec msdb.sys.sp_dbmmonitorupdate @l_DatabaseName
            INSERT INTO #tempTable(
            database_name,[role],mirroring_state ,
            witness_status,log_generation_rate ,unsent_log ,send_rate ,
            unrestored_log ,recovery_rate ,transaction_delay,
            transactions_per_sec ,average_delay ,time_recorded ,time_behind  ,local_time)
            EXEC msdb.dbo.sp_dbmmonitorresults @l_DatabaseName,0,0;
            SELECT @l_i = MIN(database_id)
            FROM #mirrorDatabases
            WHERE database_id > @l_i
        END
            SELECT database_name AS DatabaseName,
                       mirroring_state AS MirrorState,
                       CASE mirroring_state WHEN 0 THEN 'Suspended'
                                            WHEN 1 THEN 'Disconnected'
                                            WHEN 2 THEN 'Synchronizing'
                                            WHEN 3 THEN 'Pending Failover'
                                            WHEN 4 THEN 'Synchronized'
                                            END AS MirrorStateDescription,
                       role AS [Role],--1: Principal, 2:Mirror
                       unsent_log/1024/1024.0 AS UnsentLogInGB, --Unsent_Log size in primary server KB
                       time_recorded AS TimeRecorded,
                       time_behind AS TimeBehind,
                       datediff(mi,time_recorded,time_behind) AS AgeOfTheOldestUnsentTransaction,
                   unrestored_log/1024/1024.0 AS UnrestoredLogInGB,
                       recovery_rate AS RecoveryRate, -- KB/Sec
                       CASE WHEN recovery_rate=0 THEN NULL ELSE (unrestored_log/recovery_rate/60) END AS TimeToRestoreLog -- Minutes
                FROM #tempTable
                --WHERE mirroring_state NOT IN (2,4) --State; 0 = Suspended;1 = Disconnected;2 = Synchronizing; 3 = Pending Failover;4 = Synchronized
drop table #tempTable
drop table #mirrorDatabases
END