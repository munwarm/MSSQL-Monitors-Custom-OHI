SELECT name as DBName,state_desc as DBState
from sys.databases