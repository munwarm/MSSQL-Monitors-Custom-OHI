select db_name(database_id) AS database_name,mirroring_state_desc,mirroring_role_desc,mirroring_partner_instance
from sys.database_mirroring
where mirroring_guid IS NOT NULL