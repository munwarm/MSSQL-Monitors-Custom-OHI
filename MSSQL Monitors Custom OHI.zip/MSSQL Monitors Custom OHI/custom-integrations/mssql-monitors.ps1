[string[]]$dbstr = Get-Content "C:\Program Files\New Relic\newrelic-infra\integrations.d\mssql-monitors-config.yml" | Where-Object {$_ -like '*database:*'}
$dbarr = $dbstr -split ':'

[string[]]$usrstr = Get-Content "C:\Program Files\New Relic\newrelic-infra\integrations.d\mssql-monitors-config.yml" | Where-Object {$_ -like '*username:*'}
$usrarr = $usrstr -split ':'

[string[]]$pwdstr = Get-Content "C:\Program Files\New Relic\newrelic-infra\integrations.d\mssql-monitors-config.yml" | Where-Object {$_ -like '*password:*'}
$pwdarr = $pwdstr -split ':'

$output = @{"name" = "com.newrelic.mssql-jobs"; "protocol_version" = "1"; integration_version = "0.1.0"}

$Database = $dbarr[1].Trim()
$UserName = $usrarr[1].Trim()
$Passwd = $pwdarr[1].Trim()

$output.metrics = @()
$output.inventory = @{}
$output.events = @()

$results1 = Invoke-Sqlcmd -Database $Database -Username $UserName -Password $Passwd -inputFile "C:\Program Files\New Relic\newrelic-infra\custom-integrations\SQLAgentHealth.sql"
$results2 = Invoke-Sqlcmd -Database $Database -Username $UserName -Password $Passwd -inputFile "C:\Program Files\New Relic\newrelic-infra\custom-integrations\SQLServerDBMirrorStatus.sql" 
$results3 = Invoke-Sqlcmd -Database $Database -Username $UserName -Password $Passwd -inputFile "C:\Program Files\New Relic\newrelic-infra\custom-integrations\SQLServerDBStatus.sql" 
$results4 = Invoke-Sqlcmd -Database $Database -Username $UserName -Password $Passwd -inputFile "C:\Program Files\New Relic\newrelic-infra\custom-integrations\SQLServerDBUnsentLog.sql" 
$results5 = Invoke-Sqlcmd -Database $Database -Username $UserName -Password $Passwd -inputFile "C:\Program Files\New Relic\newrelic-infra\custom-integrations\SQLServerInstanceStatus.sql" 
$results6 = Invoke-Sqlcmd -Database $Database -Username $UserName -Password $Passwd -inputFile "C:\Program Files\New Relic\newrelic-infra\custom-integrations\SQLServerSyncHealth.sql" 


if ($results1.Count -gt 0) {
  $results1 | ForEach-Object {$output.metrics += @{"event_type" = "SQLAgentHealth";"Job Name" = "$($_.'JobName')";"Job Description" = "$($_.'JobDescription')";"Last Run Date" = "$($_.'last_run_date')";"Last Run Time" = "$($_.'last_run_time')";"Last Run Date Time" = "$($_.'LastRunDateTime')";"Last Run Duration" = "$($_.'LastRunDuration')";"Last Run End Date Time" = "$($_.'LastRunEndDateTime')";"Last Outcome Message" = "$($_.'last_outcome_message')"}}
}

if ($results2.Count -gt 0) {
  $results2 | ForEach-Object {$output.metrics += @{"event_type" = "SQLServerDBMirrorStatus";"Database Name" = "$($_.'database_name')";"Mirroring State Desc" = "$($_.'mirroring_state_desc')";"Mirroring Role Desc" = "$($_.'mirroring_role_desc')";"Mirroring Partner Instance" = "$($_.'mirroring_partner_instance')"}}
}

if ($results3.Count -gt 0) {
  $results3 | ForEach-Object {$output.metrics += @{"event_type" = "SQLServerDBStatus";"DB Name" = "$($_.'DBName')";"DB State" = "$($_.'DBState')"}}
}

if ($results4.Count -gt 0) {
  $results4 | ForEach-Object {$output.metrics += @{"event_type" = "SQLServerDBUnsentLog";"Database Name" = "$($_.'DatabaseName')";"Mirror State" = "$($_.'MirrorState')";"Mirror State Description" = "$($_.'MirrorStateDescription')";"Role" = "$($_.'Role')";"Unsent Log In GB" = "$($_.'UnsentLogInGB')";"Time Recorded" = "$($_.'TimeRecorded')";"Time Behind" = "$($_.'TimeBehind')";"Age Of The Oldest Unsent Transaction" = "$($_.'AgeOfTheOldestUnsentTransaction')";"Unrestored Log In GB" = "$($_.'UnrestoredLogInGB')";"Recovery Rate" = "$($_.'RecoveryRate')";"Time To Restore Log" = "$($_.'TimeToRestoreLog')"}}
}

if ($results5.Count -gt 0) {
  $results5 | ForEach-Object {$output.metrics += @{"event_type" = "SQLServerInstanceStatus";"Instance Status" = "$($_.'InstanceStatus')"}}
}

if ($results6.Count -gt 0) {
  $results6 | ForEach-Object {$output.metrics += @{"event_type" = "SQLServerSyncHealth";"AG Name" = "$($_.'AGName')";"Server Name" = "$($_.'ServerName')";"DB" = "$($_.'DB')";"Health Status" = "$($_.'HealthStatus')";"Sync Status" = "$($_.'SyncStatus')";"Last Commit Time" = "$($_.'LastCommitTime')"}}
}

$output | ConvertTo-Json -Compress