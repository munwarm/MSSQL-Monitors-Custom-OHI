SELECT t2.name AS AGName, t3.replica_server_name ServerName, DB_NAME(t1.database_id) AS DB,
            t1.synchronization_health_desc AS HealthStatus,
            t1.synchronization_state_desc AS SyncStatus, t1.last_commit_time AS LastCommitTime
FROM sys.dm_hadr_database_replica_states t1
    INNER JOIN sys.availability_groups t2 ON t1.group_id=t2.group_id
    INNER JOIN sys.dm_hadr_availability_replica_cluster_states t3 ON t1.replica_id=t3.replica_id AND t1.group_id=t3.group_id
ORDER BY AGName, DB, ServerName